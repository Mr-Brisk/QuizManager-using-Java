package epita.quiz;

/**
 *
 */
public class MCQAnswer {

    /**
     * Default constructor
     */
    public MCQAnswer() {
    }

    MCQChoice objMCQChoice;
    Quiz objQuiz;
    Student objStudent;
    
    
    
}
